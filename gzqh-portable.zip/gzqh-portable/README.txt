gzqh-portable
================

This package is sanitized for redistribution.
It does not include your live public IPs.

One-command startup:
  cd gzqh-portable && bash install.sh && gzqh

What to configure after launch:
1. Add/modify backup lines in menu item 3.
2. Change entry port in menu item 4 if needed.
3. Set fail / backup-check / recover timings in menu items 5 and 6.

Notes:
- This package installs the menu tool to /usr/local/bin/gzqh.
- The failover worker script is installed to /opt/cf_ss_failover.py.
- nftables must be available on the target machine. The menu's install/repair flow can install nftables if missing.
