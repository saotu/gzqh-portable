gzqh-portable
=============

Install:
  bash install.sh

Or online:
  bash <(curl -fsSL https://raw.githubusercontent.com/saotu/gzqh-portable/main/launch.sh)

Menu:
  7)  service control
  88) one-click update from GitHub release
  99) uninstall

Fix 2026-07-15:
  When on backup, primary recovery is counted even if all backups are FAIL.
  Previously backup rotation returned early and starved recover_count forever.
