#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "$0")" && pwd)"
install -m 0755 "$ROOT_DIR/gzqh" /usr/local/bin/gzqh
install -m 0755 "$ROOT_DIR/cf_ss_failover.py" /opt/cf_ss_failover.py
mkdir -p /opt/ss-failover
cat <<'EOF'
Installed:
  /usr/local/bin/gzqh
  /opt/cf_ss_failover.py

Start with:
  gzqh

One-command startup after unzip:
  cd gzqh-portable && bash install.sh && gzqh
EOF
